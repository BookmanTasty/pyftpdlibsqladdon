# This line of code will allow shorter imports
from pyftpdlibsqladdon.dummysqlauthorizer import DummySqlAuthorizer